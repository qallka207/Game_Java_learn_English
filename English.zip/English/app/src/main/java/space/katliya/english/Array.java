package space.katliya.english;

public class Array {
    //1
    final int[] image1 = {
            R.drawable.girl,
            R.drawable.boy,
            R.drawable.book,
            R.drawable.bird,

            R.drawable.man,
            R.drawable.book,
            R.drawable.egg,
            R.drawable.bird,

            R.drawable.woman,
            R.drawable.egg,
            R.drawable.boy,
            R.drawable.book,

            R.drawable.man,
            R.drawable.book,
            R.drawable.woman,
            R.drawable.egg,

            R.drawable.bird,
            R.drawable.boy,
            R.drawable.woman,
            R.drawable.man,
    };

    final int[] text1 = {
            R.string.girl,
            R.string.boy,
            R.string.book,
            R.string.bird,

            R.string.man,
            R.string.book,
            R.string.egg,
            R.string.bird,

            R.string.woman,
            R.string.egg,
            R.string.boy,
            R.string.book,

            R.string.man,
            R.string.book,
            R.string.woman,
            R.string.egg,

            R.string.bird,
            R.string.boy,
            R.string.woman,
            R.string.man,
    };

    final int[] vopros = {
            R.string.v1,
            R.string.v2,
            R.string.v3,
            R.string.v4,
            R.string.v5,
    };

    //2
    final int[] bukva1 = {
            R.string.m,
            R.string.s,
            R.string.p,
            R.string.w,
            R.string.d,
    };

    final int[] bukva3 = {
            R.string.n,
            R.string.n,
            R.string.n,
            R.string.man,
            R.string.ll,
    };

    final int[] image2 = {
            R.drawable.man,
            R.drawable.sun,
            R.drawable.pen,
            R.drawable.woman,
            R.drawable.doll,
    };

    //3
    final int[] vopros3 = {
            R.string.q1,
            R.string.q2,
            R.string.q3,
            R.string.q4,
            R.string.q5,
    };

    //4
    final int[] image4 = {
            R.drawable.mouse,
            R.drawable.man,
            R.drawable.egg,
            R.drawable.cat,

            R.drawable.mouse,
            R.drawable.cat,
            R.drawable.dog,
            R.drawable.owl,

            R.drawable.doll,
            R.drawable.rabbit,
            R.drawable.cat,
            R.drawable.woman,

            R.drawable.book,
            R.drawable.mouse,
            R.drawable.owl,
            R.drawable.dog,

            R.drawable.man,
            R.drawable.dog,
            R.drawable.woman,
            R.drawable.rabbit,
    };

    final int[] text4 = {
            R.string.mouse,
            R.string.man,
            R.string.egg,
            R.string.cat,

            R.string.mouse,
            R.string.cat,
            R.string.dog,
            R.string.owl,

            R.string.doll,
            R.string.rabbit,
            R.string.cat,
            R.string.woman,

            R.string.book,
            R.string.mouse,
            R.string.owl,
            R.string.dog,

            R.string.man,
            R.string.dog,
            R.string.woman,
            R.string.rabbit,
    };

    final int[] vopros4 = {
            R.string.v41,
            R.string.v42,
            R.string.v43,
            R.string.v44,
            R.string.v45,
    };

    //5
    final int[] bukva51 = {
            R.string.m,
            R.string.c,
            R.string.d,
            R.string.o,
            R.string.rab,
    };

    final int[] bukva53 = {
            R.string.use,
            R.string.t,
            R.string.g,
            R.string.l,
            R.string.it,
    };

    final int[] image5 = {
            R.drawable.mouse,
            R.drawable.cat,
            R.drawable.dog,
            R.drawable.owl,
            R.drawable.rabbit,
    };

    final int[] dialog = {
            R.drawable.df,
            R.drawable.de,
            R.drawable.dd,
            R.drawable.dc,
            R.drawable.db,
            R.drawable.dda,
    };

    //6
    final int[] vopros6 = {
            R.string.q61,
            R.string.q62,
            R.string.q63,
            R.string.q64,
            R.string.q65,
    };

    //7
    final int[] image7 = {
            R.drawable.girl,
            R.drawable.apple,
            R.drawable.book,
            R.drawable.orange,

            R.drawable.banana,
            R.drawable.book,
            R.drawable.egg,
            R.drawable.pineapple,

            R.drawable.donut,
            R.drawable.apple,
            R.drawable.boy,
            R.drawable.orange,

            R.drawable.dog,
            R.drawable.pineapple,
            R.drawable.orange,
            R.drawable.egg,

            R.drawable.apple,
            R.drawable.boy,
            R.drawable.woman,
            R.drawable.pineapple,
    };

    final int[] text7 = {
            R.string.girl,
            R.string.apple,
            R.string.book,
            R.string.orange,

            R.string.banana,
            R.string.book,
            R.string.egg,
            R.string.pineapple,

            R.string.donut,
            R.string.apple,
            R.string.boy,
            R.string.orange,

            R.string.dog,
            R.string.pineapple,
            R.string.orange,
            R.string.egg,

            R.string.apple,
            R.string.boy,
            R.string.woman,
            R.string.pineapple,
    };

    final int[] vopros7 = {
            R.string.v71,
            R.string.v72,
            R.string.v73,
            R.string.v74,
            R.string.v75,
    };

    //8
    final int[] bukva81 = {
            R.string.ap,
            R.string.ban,
            R.string.d,
            R.string.oran,
            R.string.pine,
    };

    final int[] bukva83 = {
            R.string.le,
            R.string.na,
            R.string.nut,
            R.string.e,
            R.string.pple,
    };

    final int[] image8 = {
            R.drawable.apple,
            R.drawable.banana,
            R.drawable.donut,
            R.drawable.orange,
            R.drawable.pineapple,
    };

    //9
    final int[] vopros93 = {
            R.string.q91,
            R.string.q92,
            R.string.q93,
            R.string.q94,
            R.string.q95,
    };

    //10
    final int[] image10 = {
            R.drawable.red,
            R.drawable.orange1,
            R.drawable.book,
            R.drawable.pink,

            R.drawable.orange1,
            R.drawable.book,
            R.drawable.egg,
            R.drawable.yellow,

            R.drawable.pink,
            R.drawable.apple,
            R.drawable.boy,
            R.drawable.green,

            R.drawable.pink,
            R.drawable.green,
            R.drawable.orange1,
            R.drawable.egg,

            R.drawable.apple,
            R.drawable.boy,
            R.drawable.yellow,
            R.drawable.green,
    };

    final int[] text10 = {
            R.string.red,
            R.string.orange,
            R.string.book,
            R.string.pink,

            R.string.orange,
            R.string.book,
            R.string.egg,
            R.string.yellow,

            R.string.pink,
            R.string.apple,
            R.string.boy,
            R.string.green,

            R.string.pink,
            R.string.green,
            R.string.orange,
            R.string.egg,

            R.string.apple,
            R.string.boy,
            R.string.yellow,
            R.string.green,
    };

    final int[] vopros10 = {
            R.string.v101,
            R.string.v102,
            R.string.v103,
            R.string.v104,
            R.string.v105,
    };

    //11
    final int[] bukva111 = {
            R.string.r,
            R.string.or,
            R.string.g,
            R.string.p,
            R.string.y,
    };

    final int[] bukva113 = {
            R.string.d,
            R.string.nge,
            R.string.een,
            R.string.nk,
            R.string.llow,
    };

    final int[] image11 = {
            R.drawable.red,
            R.drawable.orange1,
            R.drawable.green,
            R.drawable.pink,
            R.drawable.yellow,
    };

    //12
    final int[] vopros12 = {
            R.string.q121,
            R.string.q122,
            R.string.q123,
            R.string.q124,
            R.string.q125,
    };

}
